import{a8 as n,r as a}from"./DJSmrRIn.js";const c=n("cart",()=>{const r=a(null),o=a(null);return{cart:r,cartBottom:o,initCart:t=>r.value=t,initCartBottom:t=>o.value=t}});export{c as u};
